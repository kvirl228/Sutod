package org.example.sutod_auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SutodAuthApplication {

    public static void main(String[] args) {
        SpringApplication.run(SutodAuthApplication.class, args);
    }

}
