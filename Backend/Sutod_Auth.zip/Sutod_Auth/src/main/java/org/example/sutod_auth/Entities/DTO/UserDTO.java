package org.example.sutod_auth.Entities.DTO;

import lombok.Data;

@Data
public class UserDTO {
    private Long id;
    private String username;
}
